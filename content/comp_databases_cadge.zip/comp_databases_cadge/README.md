# CAMLC 2025 Computational Chemistry Databases Tutorial

This GitHub repository contains the data and Jupyter notebooks required to run the Tutorial exercises extracting and modeling with descriptors pulled from the MolSSI website.

> [!NOTE]
> The [Descriptors Library Project](https://descriptor-libraries.molssi.org/) is a collaboration between the [NSF Center for Computer Assisted Synthesis (C-CAS)](https://ccas.nd.edu/) and the [NSF Molecular Sciences Software Institute (MolSSI)](https://molssi.org/). It hosts a growing number of computational databases free-of-charge generated within C-CAS.

> [!IMPORTANT]
> The Python environment you installed for CAMLC should work with these tutorials. There is one additional package that you need to install - the "requests" package used for communicating with the MolSSI website. Just run `pip install requests`!

## Tutorial learning outcomes
- Be able to download DFT features for a monophosphine ligand using the MolSSI API and it's DFT-optimized confomer structures.
- Be able to download a table of features based on a pre-aquired dataset.
- Generate a model using the features obtained from MolSSI using ROBERT.

## Files in this repository

- `acids_api_demo.ipynb` - Jupyter notebook we'll use to explore some of the features of the MolSSI Descriptor Library Project's API
- `kraken_api_tutorial.ipynb` - A template Jupyter notebook you'll use to try the API for yourself